package com.tcs.angularjs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyAwesomeSpringBootAngularJsApp {

    public static void main(String[] args) {
        SpringApplication.run(MyAwesomeSpringBootAngularJsApp.class, args);
    }
}
